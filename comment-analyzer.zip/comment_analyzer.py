#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
برنامج تحليل التعليقات التلقائي باستخدام Gemini API
يقسم التعليقات إلى مجموعات من 10، يرسلها إلى Gemini، ويحفظ النتائج مباشرة في ملف Excel.
يدعم استئناف العمل عند التوقف وإعادة المحاولة التلقائية عند حدوث Rate Limit.
"""

import os
import sys
import time
import json
import configparser
import requests
from pathlib import Path

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    print("خطأ: مكتبة openpyxl غير مثبتة. يرجى تشغيل: pip install openpyxl requests")
    sys.exit(1)


def load_api_key():
    """تحميل مفتاح Gemini API من ملف config.ini أو .env أو متغيرات البيئة"""
    # 1. فحص متغيرات البيئة
    if os.environ.get("GEMINI_API_KEY"):
        return os.environ.get("GEMINI_API_KEY").strip()

    # 2. فحص ملف config.ini
    config_file = Path("config.ini")
    if config_file.exists():
        config = configparser.ConfigParser()
        config.read(config_file, encoding="utf-8")
        if "GEMINI" in config and "API_KEY" in config["GEMINI"]:
            key = config["GEMINI"]["API_KEY"].strip()
            if key and key != "YOUR_GEMINI_API_KEY_HERE":
                return key

    # 3. فحص ملف .env
    env_file = Path(".env")
    if env_file.exists():
        with open(env_file, "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("GEMINI_API_KEY="):
                    val = line.split("=", 1)[1].strip().strip('"').strip("'")
                    if val and val != "MY_GEMINI_API_KEY":
                        return val

    return None


def call_gemini_api(prompt, batch_number, comments, api_key, max_retries=3):
    """
    إرسال الدفعة إلى Gemini مع إعادة المحاولة التلقائية في حال حدوث Rate Limit (429) أو انقطاع
    """
    model = "gemini-2.5-flash"
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"

    formatted_comments = "\n".join([f"{i+1}. {c}" for i, c in enumerate(comments)])
    full_prompt = (
        f"المهمة:\n{prompt.strip()}\n\n"
        f"المجموعة رقم [{batch_number}] (تحتوي على {len(comments)} تعليق):\n"
        f"{formatted_comments}\n\n"
        "قدم تحليلك الواضح لهذه المجموعة بناءً على التعليمات أعلاه."
    )

    payload = {
        "contents": [
            {
                "parts": [{"text": full_prompt}]
            }
        ],
        "generationConfig": {
            "temperature": 0.4
        }
    }

    delay_sec = 3
    for attempt in range(1, max_retries + 1):
        try:
            resp = requests.post(
                url,
                headers={"Content-Type": "application/json"},
                json=payload,
                timeout=60
            )

            if resp.status_code == 200:
                data = resp.json()
                candidates = data.get("candidates", [])
                if candidates:
                    parts = candidates[0].get("content", {}).get("parts", [])
                    if parts:
                        return True, parts[0].get("text", "").strip()
                return True, "تم استلام رد بدون محتوى نصي"

            elif resp.status_code == 429:
                # خطأ تجاوز المعدل Rate Limit
                print(f"⚠️ [المجموعة {batch_number}] تجاوز حد المعدل (Rate Limit). محاولة {attempt}/{max_retries} بعد {delay_sec} ثوانٍ...")
                time.sleep(delay_sec)
                delay_sec *= 2  # تراجع أسي

            elif resp.status_code >= 500:
                print(f"⚠️ [المجموعة {batch_number}] خطأ من خادم Gemini ({resp.status_code}). إعادة المحاولة {attempt}/{max_retries}...")
                time.sleep(delay_sec)
                delay_sec *= 2

            else:
                err_msg = resp.text
                try:
                    err_json = resp.json()
                    err_msg = err_json.get("error", {}).get("message", resp.text)
                except Exception:
                    pass
                return False, f"خطأ HTTP {resp.status_code}: {err_msg}"

        except requests.exceptions.RequestException as e:
            print(f"⚠️ [المجموعة {batch_number}] انقطاع في الاتصال: {e}. إعادة المحاولة {attempt}/{max_retries}...")
            time.sleep(delay_sec)
            delay_sec *= 2

    return False, f"فشل بعد {max_retries} محاولات بسبب مشاكل في الشبكة أو تجاوز معدل الطلبات"


def setup_or_load_workbook(excel_path):
    """
    إنشاء أو تحميل ملف Excel الحالي لاستئناف العمل
    يرجع (workbook, worksheet, set_of_completed_batch_numbers)
    """
    completed_batches = set()

    if os.path.exists(excel_path):
        try:
            wb = openpyxl.load_workbook(excel_path)
            ws = wb.active
            # قراءة المجموعات التي اكتملت بنجاح سابقاً
            for row in range(2, ws.max_row + 1):
                batch_cell = ws.cell(row=row, column=1).value
                status_cell = ws.cell(row=row, column=4).value
                if batch_cell is not None:
                    try:
                        b_num = int(batch_cell)
                        if status_cell and "نجاح" in str(status_cell):
                            completed_batches.add(b_num)
                    except ValueError:
                        pass
            print(f"🔄 تم اكتشاف ملف Excel موجود: تم تخطي {len(completed_batches)} مجموعة مكتملة سابقاً.")
            return wb, ws, completed_batches
        except Exception as e:
            print(f"تحذير: تعذر قراءة الملف السابق ({e})، سيتم إنشاء ملف جديد.")

    # إنشاء ملف جديد
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "تحليل التعليقات"
    ws.sheet_view.rightToLeft = True

    # العناوين الأربعة المطلوبة
    headers = [
        "رقم المجموعة",
        "التعليقات الأصلية",
        "رد Gemini",
        "حالة الطلب"
    ]
    ws.append(headers)

    # تنسيق رأس الجدول
    header_fill = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
    header_font = Font(name="Calibri", size=12, bold=True, color="FFFFFF")
    center_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

    for col_idx in range(1, 5):
        cell = ws.cell(row=1, column=col_idx)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = center_align

    # تعيين عرض الأعمدة لسهولة القراءة
    ws.column_dimensions["A"].width = 16
    ws.column_dimensions["B"].width = 50
    ws.column_dimensions["C"].width = 65
    ws.column_dimensions["D"].width = 18

    wb.save(excel_path)
    return wb, ws, completed_batches


def process_comments_file(txt_file_path, prompt, excel_path="نتائج_تحليل_التعليقات.xlsx", api_key=None):
    """
    الدالة الرئيسية لمعالجة الملف بالكامل خطوة بخطوة
    """
    if not api_key:
        api_key = load_api_key()

    if not api_key:
        print("\n❌ خطأ: لم يتم العثور على مفتاح Gemini API Key!")
        print("يرجى وضع المفتاح في ملف config.ini أو إدخاله عند الطلب.\n")
        return

    if not os.path.exists(txt_file_path):
        print(f"\n❌ خطأ: ملف التعليقات غير موجود: {txt_file_path}\n")
        return

    # 1. قراءة التعليقات وتجهيزها
    comments = []
    with open(txt_file_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            c = line.strip()
            if c:
                comments.append(c)

    total_comments = len(comments)
    if total_comments == 0:
        print("❌ الملف المختار لا يحتوي على أي أسطر نصية.")
        return

    # تقسيم إلى مجموعات من 10 تعليقات
    batch_size = 10
    batches = [comments[i:i + batch_size] for i in range(0, total_comments, batch_size)]
    total_batches = len(batches)

    print("\n" + "=" * 60)
    print("🚀 بدء برنامج تحليل التعليقات بواسطة Gemini API")
    print("=" * 60)
    print(f"📄 الملف المستهدف: {txt_file_path}")
    print(f"📊 إجمالي التعليقات: {total_comments} تعليق")
    print(f"📦 إجمالي المجموعات: {total_batches} مجموعة (10 تعليقات لكل مجموعة)")
    print(f"💾 ملف الإكسل الناتج: {excel_path}")
    print("=" * 60 + "\n")

    # 2. تحميل ملف Excel الحالي أو إنشاؤه
    wb, ws, completed_batches = setup_or_load_workbook(excel_path)

    border_thin = Border(
        left=Side(style='thin', color='E5E7EB'),
        right=Side(style='thin', color='E5E7EB'),
        top=Side(style='thin', color='E5E7EB'),
        bottom=Side(style='thin', color='E5E7EB')
    )
    align_top_wrap = Alignment(vertical="top", wrap_text=True)

    # 3. معالجة المجموعات تباعاً
    success_count = len(completed_batches)
    failed_count = 0

    for idx, batch_comments in enumerate(batches):
        batch_number = idx + 1

        # تخطي المجموعات المكتملة مسبقاً إذا تم إعادة تشغيل البرنامج
        if batch_number in completed_batches:
            continue

        remaining = total_batches - (idx + 1)
        progress_pct = int(((idx + 1) / total_batches) * 100)

        print(f"⏳ معالجة المجموعة [{batch_number}/{total_batches}] ({progress_pct}%)... [متبقي: {remaining}]")

        success, response_text = call_gemini_api(
            prompt=prompt,
            batch_number=batch_number,
            comments=batch_comments,
            api_key=api_key
        )

        status_text = "مكتمل بنجاح" if success else f"فشل: {response_text[:30]}"
        if success:
            success_count += 1
            print(f"  ✅ تم استلام رد Gemini للمجموعة {batch_number}")
        else:
            failed_count += 1
            print(f"  ❌ خطأ في المجموعة {batch_number}: {response_text}")

        # تجهيز التعليقات الأصلية مرقمة
        original_formatted = "\n".join([f"{i+1}. {c}" for i, c in enumerate(batch_comments)])

        # كتابة الصف في ملف Excel
        row_values = [
            batch_number,
            original_formatted,
            response_text,
            status_text
        ]
        ws.append(row_values)

        # تنسيق الخلايا المضافة حديثاً
        current_row = ws.max_row
        for col_idx in range(1, 5):
            c = ws.cell(row=current_row, column=col_idx)
            c.border = border_thin
            c.alignment = align_top_wrap

        # 4. حفظ ملف Excel مباشرة بعد كل مجموعة لضمان عدم ضياع أي بيانات
        try:
            wb.save(excel_path)
        except PermissionError:
            print("⚠️ تحذير: ملف Excel مفتوح في برنامج آخر، يرجى إغلاقه ليتمكن البرنامج من الحفظ.")

        # راحة قصيرة لتفادي Rate Limits
        time.sleep(1)

    print("\n" + "=" * 60)
    print("🎉 انتهت المعالجة بنجاح!")
    print(f"✔️ مجموعات مكتملة: {success_count} / {total_batches}")
    if failed_count > 0:
        print(f"⚠️ مجموعات فشلت: {failed_count}")
    print(f"📂 تم حفظ التقرير في: {os.path.abspath(excel_path)}")
    print("=" * 60 + "\n")


def run_simple_gui():
    """واجهة رسومية بسيطة جداً باستخدام tkinter المدمجة في بايثون"""
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
    except ImportError:
        print("tkinter غير متوفر، سيتم استخدام وضع سطر الأوامر.")
        return False

    root = tk.Tk()
    root.title("محلل التعليقات الذكي - Gemini API")
    root.geometry("640x560")
    root.resizable(False, False)

    # Variables
    file_path_var = tk.StringVar()
    key_var = tk.StringVar(value=load_api_key() or "")
    default_prompt = "حلل هذه التعليقات الـ 10 بالتفصيل: حدد نبرة كل تعليق (إيجابي/سلبي/محايد)، المشاكل والشكاوى، ونقاط القوة، وقدم ملخص تنفيذي."

    # Header
    header = tk.Label(root, text="محلل التعليقات التلقائي إلى Excel", font=("Arial", 14, "bold"), fg="#1E3A8A")
    header.pack(pady=10)

    # API Key Frame
    key_frame = tk.LabelFrame(root, text="1. مفتاح Gemini API Key", padx=10, pady=8)
    key_frame.pack(fill="x", padx=15, pady=5)
    key_entry = tk.Entry(key_frame, textvariable=key_var, show="*", width=55)
    key_entry.pack(side="left", fill="x", expand=True)

    # File Selection Frame
    file_frame = tk.LabelFrame(root, text="2. ملف التعليقات (TXT)", padx=10, pady=8)
    file_frame.pack(fill="x", padx=15, pady=5)
    file_label = tk.Label(file_frame, textvariable=file_path_var, fg="#2563EB", anchor="w")
    file_label.pack(side="left", fill="x", expand=True)

    def select_file():
        fn = filedialog.askopenfilename(filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if fn:
            file_path_var.set(fn)

    btn_browse = tk.Button(file_frame, text="اختيار ملف TXT...", command=select_file)
    btn_browse.pack(side="right")

    # Prompt Frame
    prompt_frame = tk.LabelFrame(root, text="3. التعليمات / Prompt", padx=10, pady=8)
    prompt_frame.pack(fill="both", expand=True, padx=15, pady=5)
    prompt_text = tk.Text(prompt_frame, height=5, wrap="word")
    prompt_text.insert("1.0", default_prompt)
    prompt_text.pack(fill="both", expand=True)

    # Status & Progress Frame
    status_label = tk.Label(root, text="جاهز للبدء. اختر ملفاً واضغط على زر البدء.", fg="#4B5563")
    status_label.pack(pady=5)
    progress_bar = ttk.Progressbar(root, orient="horizontal", mode="indeterminate")
    progress_bar.pack(fill="x", padx=15, pady=5)

    def start_process():
        key = key_var.get().strip()
        f_path = file_path_var.get().strip()
        p_text = prompt_text.get("1.0", "end-1c").strip()

        if not key:
            messagebox.showerror("خطأ", "يرجى إدخال مفتاح Gemini API Key.")
            return
        if not f_path or not os.path.exists(f_path):
            messagebox.showerror("خطأ", "يرجى اختيار ملف TXT صالح للتعليقات.")
            return

        btn_start.config(state="disabled")
        status_label.config(text="جاري معالجة التعليقات وتقسيمها إلى دفعات...")
        progress_bar.start(10)
        root.update()

        try:
            excel_out = os.path.splitext(f_path)[0] + "_تحليل_Gemini.xlsx"
            process_comments_file(f_path, p_text, excel_out, key)
            messagebox.showinfo("تم بنجاح", f"اكتمل التحليل وتم حفظ ملف Excel بنجاح في:\n{excel_out}")
            status_label.config(text=f"تم الحفظ بنجاح: {os.path.basename(excel_out)}")
        except Exception as e:
            messagebox.showerror("حدث خطأ", str(e))
            status_label.config(text=f"خطأ: {e}")
        finally:
            progress_bar.stop()
            btn_start.config(state="normal")

    btn_start = tk.Button(
        root,
        text="▶ بدء التحليل وإنشاء ملف Excel",
        bg="#107C41",
        fg="white",
        font=("Arial", 12, "bold"),
        pady=8,
        command=start_process
    )
    btn_start.pack(fill="x", padx=15, pady=10)

    root.mainloop()
    return True


if __name__ == "__main__":
    # إذا تم تمرير مسار ملف عبر سطر الأوامر
    if len(sys.argv) > 1:
        txt_input = sys.argv[1]
        custom_prompt = sys.argv[2] if len(sys.argv) > 2 else "حلل التعليقات واستخرج المشاعر والنقاط الإيجابية والسلبية."
        process_comments_file(txt_input, custom_prompt)
    else:
        # تشغيل الواجهة الرسومية البسيطة
        if not run_simple_gui():
            sample = "comments_sample.txt"
            if os.path.exists(sample):
                print(f"تشغيل تجريبي على الملف الافتراضي: {sample}")
                process_comments_file(sample, "حلل هذه التعليقات الـ 10 بالتفصيل.")
