package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.export.ExcelExporter
import com.example.data.model.BatchItem
import com.example.data.model.BatchStatus
import com.example.data.service.GeminiApiService
import com.example.data.storage.BatchStorage
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

data class AnalyzerUiState(
    val fileName: String = "",
    val prompt: String = DEFAULT_PROMPT,
    val apiKey: String = "",
    val batches: List<BatchItem> = emptyList(),
    val isRunning: Boolean = false,
    val isPaused: Boolean = false,
    val currentBatchIndex: Int = -1,
    val statusMessage: String = "جاهز للبدء. اختر ملفاً واضغط على بدء التحليل.",
    val errorMessage: String? = null,
    val exportedExcelFile: File? = null,
    val hasRestoredSession: Boolean = false
) {
    val totalBatches: Int get() = batches.size
    val completedBatches: Int get() = batches.count { it.status == BatchStatus.SUCCESS }
    val failedBatches: Int get() = batches.count { it.status == BatchStatus.FAILED }
    val remainingBatches: Int get() = batches.count { it.status == BatchStatus.PENDING || it.status == BatchStatus.PROCESSING }
    val progress: Float get() = if (totalBatches == 0) 0f else completedBatches.toFloat() / totalBatches.toFloat()
    val canStart: Boolean get() = batches.isNotEmpty() && !isRunning
    val canExport: Boolean get() = batches.any { it.status == BatchStatus.SUCCESS || it.status == BatchStatus.FAILED }
}

const val DEFAULT_PROMPT = "حلل هذه التعليقات الـ 10 بالتفصيل: حدد نبرة كل تعليق (إيجابي/سلبي/محايد)، استخرج أبرز المشاكل والشكاوى المذكورة، واذكر نقاط القوة، ثم قدم ملخصاً تنفيذياً سريعاً."

class CommentAnalyzerViewModel(application: Application) : AndroidViewModel(application) {

    private val apiService = GeminiApiService()
    private var analysisJob: Job? = null

    private val _uiState = MutableStateFlow(AnalyzerUiState())
    val uiState: StateFlow<AnalyzerUiState> = _uiState.asStateFlow()

    init {
        // Resolve default API key from BuildConfig or environment
        val defaultKey = try {
            BuildConfig.GEMINI_API_KEY.takeIf { it.isNotBlank() && it != "MY_GEMINI_API_KEY" } ?: ""
        } catch (e: Exception) {
            ""
        }
        _uiState.update { it.copy(apiKey = defaultKey) }

        // Attempt to restore previous session from disk
        loadSavedSession()
    }

    fun loadSavedSession() {
        val context = getApplication<Application>().applicationContext
        val session = BatchStorage.loadSession(context)
        if (session != null && session.batches.isNotEmpty()) {
            val keyToUse = if (session.customApiKey.isNotBlank()) session.customApiKey else _uiState.value.apiKey
            _uiState.update { current ->
                current.copy(
                    fileName = session.fileName,
                    prompt = session.prompt.ifBlank { DEFAULT_PROMPT },
                    apiKey = keyToUse,
                    batches = session.batches,
                    hasRestoredSession = true,
                    statusMessage = "تم استعادة الجلسة السابقة (${session.batches.count { it.status == BatchStatus.SUCCESS }}/${session.batches.size} مجموعة مكتملة). يمكنك المتابعة أو تصدير النتائج."
                )
            }
        }
    }

    fun updatePrompt(newPrompt: String) {
        _uiState.update { it.copy(prompt = newPrompt) }
        saveCurrentSession()
    }

    fun updateApiKey(newKey: String) {
        _uiState.update { it.copy(apiKey = newKey) }
        saveCurrentSession()
    }

    fun loadTextFromUri(uri: Uri) {
        val context = getApplication<Application>().applicationContext
        viewModelScope.launch {
            try {
                val comments = mutableListOf<String>()
                var detectedFileName = "uploaded_comments.txt"

                // Try to get filename
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && nameIndex != -1) {
                        detectedFileName = cursor.getString(nameIndex)
                    }
                }

                context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    BufferedReader(InputStreamReader(inputStream)).use { reader ->
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            val trimmed = line?.trim()
                            if (!trimmed.isNullOrEmpty()) {
                                comments.add(trimmed)
                            }
                        }
                    }
                }

                if (comments.isEmpty()) {
                    _uiState.update {
                        it.copy(errorMessage = "الملف فارغ أو لا يحتوي على تعليقات صالحة.")
                    }
                    return@launch
                }

                setupBatches(detectedFileName, comments)
            } catch (e: Exception) {
                Log.e("CommentAnalyzer", "Error reading file", e)
                _uiState.update {
                    it.copy(errorMessage = "فشل في قراءة الملف: ${e.localizedMessage}")
                }
            }
        }
    }

    fun loadSampleComments() {
        val sampleComments = listOf(
            "التطبيق رائع وسريع جدًا، لكن أرجو إضافة خيار الوضع الليلي الداكن.",
            "خدمة العملاء بطيئة في الرد على الاستفسارات، انتظرت يومين للحصول على حل.",
            "جودة المنتج ممتازة ومطابقة تماماً للوصف والصور في المتجر.",
            "سعر الاشتراك الشهري مرتفع مقارنة بالميزات والبدائل المتاحة.",
            "واجهة المستخدم سهلة الاستخدام وبسيطة للغاية حتى للمبتدئين.",
            "يحدث إغلاق مفاجئ للتطبيق عند محاولة تصدير التقارير الطويلة.",
            "سرعة التوصيل كانت مذهلة، وصل الطلب في أقل من 24 ساعة!",
            "خيارات الدفع الإلكتروني محدودة، نأمل دعم Apple Pay و مدى.",
            "محتوى الشروحات والدروس التعليمية مفيد جداً وساعدني كثيراً.",
            "التحديث الأخير أصلح مشكلة البطارية، شكراً لفريق التطوير.",
            // Group 2
            "التطبيق يستهلك الكثير من باقة الإنترنت في الخلفية.",
            "أفضل تطبيق استخدمته هذا العام بلا منازع، استمروا في هذا التميز.",
            "الإشعارات كثيرة ومزعجة طوال اليوم، أتمنى إمكانية تخصيصها.",
            "عملية التسجيل وإنشاء الحساب معقدة وتطلب بيانات غير ضرورية.",
            "التصميم أنيق ومريح للعين والألوان متناسقة بشكل احترافي.",
            "الدعم الفني كان ودوداً جداً وقام بحل المشكلة خلال دقائق.",
            "لا توجد ميزة البحث المتقدم في سجل الطلبات القديمة.",
            "التطبيق يعمل بسلاسة وبدون أي تقطيع على هاتفي القديم.",
            "أواجه مشكلة في حفظ الملفات داخل وحدة التخزين الخارجية.",
            "أقترح إضافة ميزة المشاركة المباشرة عبر تطبيق واتساب.",
            // Group 3
            "الترجمة العربية لبعض القوائم غير دقيقة وتحتاج لمراجعة.",
            "أداء ممتاز وتجربة مستخدم تفوق التوقعات، أنصح الجميع به.",
            "أتمنى دعم المزامنة السحابية عبر أجهزة متعددة لنفس الحساب.",
            "سلة التسوق تفقد العناصر المحفوظة أحياناً بعد إعادة التشغيل.",
            "شكراً لكم على الاستجابة السريعة لملاحظات المستخدمين وتطوير التطبيق."
        )

        setupBatches("sample_comments_arabic.txt", sampleComments)
    }

    private fun setupBatches(fileName: String, comments: List<String>) {
        // Group comments into chunks of 10
        val chunks = comments.chunked(10)
        val batchItems = chunks.mapIndexed { index, batchComments ->
            BatchItem(
                batchNumber = index + 1,
                comments = batchComments,
                status = BatchStatus.PENDING
            )
        }

        _uiState.update { current ->
            current.copy(
                fileName = fileName,
                batches = batchItems,
                hasRestoredSession = false,
                errorMessage = null,
                statusMessage = "تم تجهيز ${comments.size} تعليق في ${batchItems.size} مجموعة (10 تعليقات لكل مجموعة). اضغط على 'بدء التحليل'."
            )
        }

        saveCurrentSession()
    }

    fun startOrResumeAnalysis() {
        val state = _uiState.value
        val effectiveKey = state.apiKey.trim().ifBlank {
            try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }
        }

        if (effectiveKey.isBlank() || effectiveKey == "MY_GEMINI_API_KEY") {
            _uiState.update {
                it.copy(
                    errorMessage = "يرجى إدخال مفتاح Gemini API Key صالح أولاً للاستمرار."
                )
            }
            return
        }

        if (state.batches.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "يرجى رفع ملف التعليقات أولاً.") }
            return
        }

        _uiState.update {
            it.copy(
                isRunning = true,
                isPaused = false,
                errorMessage = null,
                statusMessage = "جاري بدء التحليل..."
            )
        }

        analysisJob?.cancel()
        analysisJob = viewModelScope.launch {
            val batches = _uiState.value.batches.toMutableList()

            for (i in batches.indices) {
                // Check if user paused
                if (_uiState.value.isPaused) {
                    _uiState.update {
                        it.copy(
                            isRunning = false,
                            statusMessage = "تم إيقاف التحليل مؤقتاً. يمكنك المتابعة في أي وقت."
                        )
                    }
                    break
                }

                val currentBatch = batches[i]
                // If this batch already succeeded in this session or prior run, skip it!
                if (currentBatch.status == BatchStatus.SUCCESS) {
                    continue
                }

                // Mark current batch as processing
                batches[i] = currentBatch.copy(status = BatchStatus.PROCESSING)
                _uiState.update {
                    it.copy(
                        batches = batches.toList(),
                        currentBatchIndex = i,
                        statusMessage = "جاري إرسال المجموعة رقم ${i + 1} من أصل ${batches.size} إلى Gemini API..."
                    )
                }

                // Call Gemini API with retry logic
                val result = apiService.analyzeBatch(
                    systemOrUserPrompt = _uiState.value.prompt,
                    batchNumber = currentBatch.batchNumber,
                    comments = currentBatch.comments,
                    apiKey = effectiveKey,
                    onRetry = { attempt, delaySeconds, reason ->
                        _uiState.update { current ->
                            current.copy(
                                statusMessage = "المجموعة ${i + 1}: $reason. إعادة المحاولة ($attempt/3) خلال $delaySeconds ثانية..."
                            )
                        }
                    }
                )

                if (result.isSuccess) {
                    val reply = result.getOrNull().orEmpty()
                    batches[i] = batches[i].copy(
                        response = reply,
                        status = BatchStatus.SUCCESS,
                        errorDetails = null
                    )
                } else {
                    val error = result.exceptionOrNull()?.localizedMessage ?: "حدث خطأ غير معروف"
                    batches[i] = batches[i].copy(
                        status = BatchStatus.FAILED,
                        errorDetails = error
                    )
                }

                // CRITICAL REQUIREMENT: Save results immediately after each batch so progress is not lost!
                _uiState.update {
                    it.copy(batches = batches.toList())
                }
                saveCurrentSession()

                // Inter-batch courtesy delay (600ms)
                delay(600)
            }

            val finalCompleted = batches.count { it.status == BatchStatus.SUCCESS }
            val finalFailed = batches.count { it.status == BatchStatus.FAILED }

            _uiState.update {
                it.copy(
                    isRunning = false,
                    currentBatchIndex = -1,
                    statusMessage = if (finalCompleted == batches.size) {
                        "اكتمل تحليل جميع المجموعات بنجاح ($finalCompleted/${batches.size})! جاهز لتصدير ملف Excel."
                    } else {
                        "انتهت العملية: $finalCompleted مكتمل، $finalFailed فشل. يمكنك تصدير Excel أو إعادة المحاولة."
                    }
                )
            }
        }
    }

    fun pauseAnalysis() {
        _uiState.update {
            it.copy(
                isPaused = true,
                isRunning = false,
                statusMessage = "جاري إيقاف التحليل مؤقتاً بعد انتهاء المجموعة الحالية..."
            )
        }
        analysisJob?.cancel()
    }

    fun resetAnalysis() {
        analysisJob?.cancel()
        val context = getApplication<Application>().applicationContext
        BatchStorage.clearSession(context)
        _uiState.update {
            it.copy(
                batches = emptyList(),
                fileName = "",
                isRunning = false,
                isPaused = false,
                currentBatchIndex = -1,
                exportedExcelFile = null,
                hasRestoredSession = false,
                statusMessage = "تمت إعادة التعيين. يمكنك اختيار ملف جديد."
            )
        }
    }

    fun exportExcel(): File? {
        val context = getApplication<Application>().applicationContext
        val batches = _uiState.value.batches
        if (batches.isEmpty()) return null

        return try {
            val file = ExcelExporter.createExcelFile(context, batches, "تحليل_التعليقات")
            _uiState.update {
                it.copy(
                    exportedExcelFile = file,
                    statusMessage = "تم إنشاء ملف Excel بنجاح: ${file.name}"
                )
            }
            file
        } catch (e: Exception) {
            Log.e("CommentAnalyzer", "Excel export failed", e)
            _uiState.update {
                it.copy(errorMessage = "فشل إنشاء ملف Excel: ${e.localizedMessage}")
            }
            null
        }
    }

    fun exportCsv(): File? {
        val context = getApplication<Application>().applicationContext
        val batches = _uiState.value.batches
        if (batches.isEmpty()) return null

        return try {
            val file = ExcelExporter.createCsvFile(context, batches, "تحليل_التعليقات")
            _uiState.update {
                it.copy(
                    exportedExcelFile = file,
                    statusMessage = "تم إنشاء ملف CSV بنجاح: ${file.name}"
                )
            }
            file
        } catch (e: Exception) {
            _uiState.update {
                it.copy(errorMessage = "فشل إنشاء ملف CSV: ${e.localizedMessage}")
            }
            null
        }
    }

    fun shareExportedFile(context: Context, file: File) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val mimeType = if (file.name.endsWith(".xlsx")) {
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            } else {
                "text/csv"
            }

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "نتائج تحليل التعليقات بواسطة Gemini")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(shareIntent, "مشاركة ملف النتائج")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            Log.e("CommentAnalyzer", "Share failed", e)
            _uiState.update {
                it.copy(errorMessage = "فشل مشاركة الملف: ${e.localizedMessage}")
            }
        }
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    private fun saveCurrentSession() {
        val context = getApplication<Application>().applicationContext
        val state = _uiState.value
        if (state.batches.isNotEmpty()) {
            BatchStorage.saveSession(
                context = context,
                fileName = state.fileName,
                prompt = state.prompt,
                batches = state.batches,
                customApiKey = state.apiKey
            )
        }
    }
}
