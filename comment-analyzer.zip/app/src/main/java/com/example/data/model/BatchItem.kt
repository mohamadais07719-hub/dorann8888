package com.example.data.model

enum class BatchStatus(val labelAr: String, val labelEn: String) {
    PENDING("قيد الانتظار", "Pending"),
    PROCESSING("جاري المعالجة...", "Processing..."),
    SUCCESS("مكتمل بنجاح", "Success"),
    FAILED("فشل الطلب", "Failed")
}

data class BatchItem(
    val batchNumber: Int,
    val comments: List<String>,
    var response: String = "",
    var status: BatchStatus = BatchStatus.PENDING,
    var errorDetails: String? = null,
    var attempts: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
) {
    val originalCommentsFormatted: String
        get() = comments.mapIndexed { index, comment -> "${index + 1}. $comment" }
            .joinToString("\n")
}
