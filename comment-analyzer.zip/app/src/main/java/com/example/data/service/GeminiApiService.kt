package com.example.data.service

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class GeminiApiService {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    companion object {
        private const val TAG = "GeminiApiService"
        private const val MODEL = "gemini-3.5-flash"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"
        private const val MAX_RETRIES = 3
    }

    /**
     * Sends a batch of comments along with the prompt to Gemini API with automatic retries on Rate Limit (429) or transient errors.
     */
    suspend fun analyzeBatch(
        systemOrUserPrompt: String,
        batchNumber: Int,
        comments: List<String>,
        apiKey: String,
        onRetry: (attempt: Int, delaySeconds: Long, reason: String) -> Unit = { _, _, _ -> }
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                IllegalArgumentException("مفتاح API Key غير مضبوط. يرجى إدخال مفتاح صالح في الإعدادات.")
            )
        }

        val formattedComments = comments.mapIndexed { idx, comment ->
            "${idx + 1}. $comment"
        }.joinToString("\n")

        val fullText = buildString {
            append("المهمة:\n")
            append(systemOrUserPrompt.trim())
            append("\n\n")
            append("مجموعة التعليقات رقم [").append(batchNumber).append("] (تحتوي على ")
            append(comments.size).append(" تعليقات):\n")
            append(formattedComments)
            append("\n\nيرجى كتابة تحليلك الواضح والمفصل لهذه المجموعة بناءً على التعليمات أعلاه.")
        }

        // Build Gemini REST API JSON payload
        val requestJson = JSONObject().apply {
            val contentsArray = JSONArray().apply {
                val contentObj = JSONObject().apply {
                    val partsArray = JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", fullText)
                        })
                    }
                    put("parts", partsArray)
                }
                put(contentObj)
            }
            put("contents", contentsArray)

            val generationConfig = JSONObject().apply {
                put("temperature", 0.4)
            }
            put("generationConfig", generationConfig)
        }

        val requestBody = requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val url = "$BASE_URL?key=$apiKey"

        var lastException: Exception? = null
        var currentDelay = 2000L // 2 seconds initial backoff

        for (attempt in 1..MAX_RETRIES) {
            val httpRequest = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            try {
                client.newCall(httpRequest).execute().use { response ->
                    val responseBodyString = response.body?.string().orEmpty()

                    if (response.isSuccessful) {
                        val responseJson = JSONObject(responseBodyString)
                        val candidates = responseJson.optJSONArray("candidates")
                        if (candidates != null && candidates.length() > 0) {
                            val candidate = candidates.getJSONObject(0)
                            val content = candidate.optJSONObject("content")
                            val parts = content?.optJSONArray("parts")
                            if (parts != null && parts.length() > 0) {
                                val replyText = parts.getJSONObject(0).optString("text")
                                return@withContext Result.success(replyText)
                            }
                        }
                        return@withContext Result.success("تم استلام رد بدون محتوى نصي.")
                    } else {
                        val errorCode = response.code
                        val isRateLimit = errorCode == 429
                        val isServerError = errorCode in 500..599

                        val errorMsg = try {
                            val errJson = JSONObject(responseBodyString)
                            errJson.optJSONObject("error")?.optString("message") ?: "HTTP $errorCode"
                        } catch (e: Exception) {
                            "HTTP $errorCode: ${response.message}"
                        }

                        if ((isRateLimit || isServerError) && attempt < MAX_RETRIES) {
                            val reason = if (isRateLimit) "تم تجاوز حد المعدل (Rate Limit - 429)" else "خطأ في خادم Gemini ($errorCode)"
                            Log.w(TAG, "$reason. محاولة $attempt/$MAX_RETRIES بعد ${currentDelay / 1000} ثوانٍ...")
                            onRetry(attempt, currentDelay / 1000, reason)
                            delay(currentDelay)
                            currentDelay *= 2 // Exponential backoff
                            return@use
                        } else {
                            lastException = IOException("خطأ من Gemini ($errorCode): $errorMsg")
                            return@withContext Result.failure(lastException)
                        }
                    }
                }
            } catch (e: Exception) {
                lastException = e
                Log.w(TAG, "Network error on attempt $attempt: ${e.message}")
                if (attempt < MAX_RETRIES) {
                    onRetry(attempt, currentDelay / 1000, "انقطاع أو بطء بالشبكة: ${e.localizedMessage}")
                    delay(currentDelay)
                    currentDelay *= 2
                } else {
                    return@withContext Result.failure(
                        IOException("فشلت المحاولة بعد $MAX_RETRIES محاولات: ${e.localizedMessage}", e)
                    )
                }
            }
        }

        Result.failure(lastException ?: IOException("فشل إرسال الطلب بعد محاولات متعددة"))
    }
}
