package com.example.data.storage

import android.content.Context
import android.util.Log
import com.example.data.model.BatchItem
import com.example.data.model.BatchStatus
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.charset.StandardCharsets

data class SavedSession(
    val fileName: String,
    val prompt: String,
    val batches: List<BatchItem>,
    val customApiKey: String,
    val lastUpdated: Long
)

object BatchStorage {

    private const val TAG = "BatchStorage"
    private const val SESSION_FILE_NAME = "comment_analysis_session.json"

    fun saveSession(
        context: Context,
        fileName: String,
        prompt: String,
        batches: List<BatchItem>,
        customApiKey: String = ""
    ) {
        try {
            val root = JSONObject().apply {
                put("fileName", fileName)
                put("prompt", prompt)
                put("customApiKey", customApiKey)
                put("lastUpdated", System.currentTimeMillis())

                val batchesArray = JSONArray()
                for (batch in batches) {
                    val batchObj = JSONObject().apply {
                        put("batchNumber", batch.batchNumber)
                        put("response", batch.response)
                        // If it was interrupted mid-processing, restore as PENDING so it can be resumed
                        val statusToSave = if (batch.status == BatchStatus.PROCESSING) {
                            BatchStatus.PENDING.name
                        } else {
                            batch.status.name
                        }
                        put("status", statusToSave)
                        put("errorDetails", batch.errorDetails ?: JSONObject.NULL)
                        put("attempts", batch.attempts)
                        put("timestamp", batch.timestamp)

                        val commentsArray = JSONArray()
                        batch.comments.forEach { commentsArray.put(it) }
                        put("comments", commentsArray)
                    }
                    batchesArray.put(batchObj)
                }
                put("batches", batchesArray)
            }

            val file = File(context.filesDir, SESSION_FILE_NAME)
            file.writeText(root.toString(2), StandardCharsets.UTF_8)
            Log.d(TAG, "Session saved successfully (${batches.size} batches)")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save session", e)
        }
    }

    fun loadSession(context: Context): SavedSession? {
        val file = File(context.filesDir, SESSION_FILE_NAME)
        if (!file.exists()) return null

        return try {
            val content = file.readText(StandardCharsets.UTF_8)
            val root = JSONObject(content)
            val fileName = root.optString("fileName", "ملف تعليقات سابق")
            val prompt = root.optString("prompt", "")
            val customApiKey = root.optString("customApiKey", "")
            val lastUpdated = root.optLong("lastUpdated", 0L)

            val batchesArray = root.optJSONArray("batches") ?: JSONArray()
            val batchesList = mutableListOf<BatchItem>()

            for (i in 0 until batchesArray.length()) {
                val bObj = batchesArray.getJSONObject(i)
                val batchNumber = bObj.getInt("batchNumber")
                val response = bObj.optString("response", "")
                val statusStr = bObj.optString("status", BatchStatus.PENDING.name)
                val status = try {
                    BatchStatus.valueOf(statusStr)
                } catch (e: Exception) {
                    BatchStatus.PENDING
                }
                val errorDetails = if (bObj.isNull("errorDetails")) null else bObj.optString("errorDetails")
                val attempts = bObj.optInt("attempts", 0)
                val timestamp = bObj.optLong("timestamp", System.currentTimeMillis())

                val commentsArray = bObj.optJSONArray("comments") ?: JSONArray()
                val commentsList = mutableListOf<String>()
                for (c in 0 until commentsArray.length()) {
                    commentsList.add(commentsArray.getString(c))
                }

                batchesList.add(
                    BatchItem(
                        batchNumber = batchNumber,
                        comments = commentsList,
                        response = response,
                        status = status,
                        errorDetails = errorDetails,
                        attempts = attempts,
                        timestamp = timestamp
                    )
                )
            }

            SavedSession(
                fileName = fileName,
                prompt = prompt,
                batches = batchesList,
                customApiKey = customApiKey,
                lastUpdated = lastUpdated
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse saved session", e)
            null
        }
    }

    fun clearSession(context: Context) {
        try {
            val file = File(context.filesDir, SESSION_FILE_NAME)
            if (file.exists()) {
                file.delete()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to clear session", e)
        }
    }
}
