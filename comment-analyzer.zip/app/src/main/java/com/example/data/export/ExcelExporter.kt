package com.example.data.export

import android.content.Context
import com.example.data.model.BatchItem
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ExcelExporter {

    /**
     * Generates a valid Microsoft Excel (.xlsx) file containing:
     * 1. رقم المجموعة (Batch Number)
     * 2. التعليقات الأصلية (Original Comments)
     * 3. رد Gemini (Gemini Response)
     * 4. حالة الطلب (Request Status)
     */
    fun createExcelFile(context: Context, batches: List<BatchItem>, filenamePrefix: String = "analysis_results"): File {
        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val outputFile = File(exportDir, "${filenamePrefix}_${System.currentTimeMillis()}.xlsx")

        ZipOutputStream(FileOutputStream(outputFile)).use { zos ->
            // 1. [Content_Types].xml
            addZipFile(zos, "[Content_Types].xml", getContentTypesXml())

            // 2. _rels/.rels
            addZipFile(zos, "_rels/.rels", getRootRelsXml())

            // 3. xl/_rels/workbook.xml.rels
            addZipFile(zos, "xl/_rels/workbook.xml.rels", getWorkbookRelsXml())

            // 4. xl/workbook.xml
            addZipFile(zos, "xl/workbook.xml", getWorkbookXml())

            // 5. xl/styles.xml
            addZipFile(zos, "xl/styles.xml", getStylesXml())

            // 6. xl/worksheets/sheet1.xml
            addZipFile(zos, "xl/worksheets/sheet1.xml", getWorksheetXml(batches))
        }

        return outputFile
    }

    /**
     * Also provides a CSV fallback formatted with UTF-8 BOM so Microsoft Excel opens Arabic text without garbled characters.
     */
    fun createCsvFile(context: Context, batches: List<BatchItem>, filenamePrefix: String = "analysis_results"): File {
        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val outputFile = File(exportDir, "${filenamePrefix}_${System.currentTimeMillis()}.csv")

        OutputStreamWriter(FileOutputStream(outputFile), StandardCharsets.UTF_8).use { writer ->
            // Write UTF-8 BOM
            writer.write("\uFEFF")
            // Headers
            writer.write("رقم المجموعة,التعليقات الأصلية,رد Gemini,حالة الطلب\n")

            for (batch in batches) {
                val batchNum = batch.batchNumber.toString()
                val original = escapeCsv(batch.originalCommentsFormatted)
                val response = escapeCsv(batch.response.ifBlank { batch.errorDetails ?: "لم يكتمل بعد" })
                val status = escapeCsv(batch.status.labelAr)

                writer.write("$batchNum,$original,$response,$status\n")
            }
        }

        return outputFile
    }

    private fun escapeCsv(value: String): String {
        val clean = value.replace("\"", "\"\"")
        return "\"$clean\""
    }

    private fun addZipFile(zos: ZipOutputStream, path: String, content: String) {
        val entry = ZipEntry(path)
        zos.putNextEntry(entry)
        val bytes = content.toByteArray(StandardCharsets.UTF_8)
        zos.write(bytes, 0, bytes.size)
        zos.closeEntry()
    }

    private fun escapeXml(text: String): String {
        val sb = StringBuilder()
        for (ch in text) {
            when {
                ch == '&' -> sb.append("&amp;")
                ch == '<' -> sb.append("&lt;")
                ch == '>' -> sb.append("&gt;")
                ch == '"' -> sb.append("&quot;")
                ch == '\'' -> sb.append("&apos;")
                // XML valid character check
                ch.code in 0x20..0xD7FF || ch == '\t' || ch == '\n' || ch == '\r' || ch.code in 0xE000..0xFFFD -> {
                    sb.append(ch)
                }
                else -> {
                    // Skip invalid control characters
                }
            }
        }
        return sb.toString()
    }

    private fun getContentTypesXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
    <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
    <Default Extension="xml" ContentType="application/xml"/>
    <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
    <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
    <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>""".trimIndent()

    private fun getRootRelsXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>""".trimIndent()

    private fun getWorkbookRelsXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
    <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>""".trimIndent()

    private fun getWorkbookXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
    <sheets>
        <sheet name="تحليل التعليقات" sheetId="1" r:id="rId1"/>
    </sheets>
</workbook>""".trimIndent()

    private fun getStylesXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
    <fonts count="3">
        <font><sz val="11"/><color rgb="FF1F2937"/><name val="Segoe UI"/></font>
        <font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Segoe UI"/></font>
        <font><b/><sz val="10"/><color rgb="FF374151"/><name val="Segoe UI"/></font>
    </fonts>
    <fills count="3">
        <fill><patternFill patternType="none"/></fill>
        <fill><patternFill patternType="gray125"/></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FF1E3A8A"/></patternFill></fill>
    </fills>
    <borders count="2">
        <border><left/><right/><top/><bottom/></border>
        <border>
            <left style="thin"><color rgb="FFE5E7EB"/></left>
            <right style="thin"><color rgb="FFE5E7EB"/></right>
            <top style="thin"><color rgb="FFE5E7EB"/></top>
            <bottom style="thin"><color rgb="FFE5E7EB"/></bottom>
        </border>
    </borders>
    <cellStyleXfs count="1">
        <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
    </cellStyleXfs>
    <cellXfs count="3">
        <!-- 0: Normal -->
        <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
        <!-- 1: Header (Navy background, bold white text, centered) -->
        <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">
            <alignment horizontal="center" vertical="center" wrapText="1"/>
        </xf>
        <!-- 2: Data row (Border, top aligned, wrap text) -->
        <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1">
            <alignment vertical="top" wrapText="1"/>
        </xf>
    </cellXfs>
</styleSheet>""".trimIndent()

    private fun getWorksheetXml(batches: List<BatchItem>): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
    <sheetViews>
        <sheetView tabSelected="1" workbookViewId="0" rightToLeft="1"/>
    </sheetViews>
    <sheetFormatPr defaultRowHeight="24"/>
    <cols>
        <col min="1" max="1" width="16" customWidth="1"/>
        <col min="2" max="2" width="48" customWidth="1"/>
        <col min="3" max="3" width="60" customWidth="1"/>
        <col min="4" max="4" width="20" customWidth="1"/>
    </cols>
    <sheetData>
""")

        // Header Row
        sb.append("""        <row r="1" ht="28" customHeight="1">
            <c r="A1" s="1" t="inlineStr"><is><t>رقم المجموعة</t></is></c>
            <c r="B1" s="1" t="inlineStr"><is><t>التعليقات الأصلية</t></is></c>
            <c r="C1" s="1" t="inlineStr"><is><t>رد Gemini</t></is></c>
            <c r="D1" s="1" t="inlineStr"><is><t>حالة الطلب</t></is></c>
        </row>
""")

        // Data Rows
        var rowIdx = 2
        for (batch in batches) {
            val originalEscaped = escapeXml(batch.originalCommentsFormatted)
            val responseText = if (batch.response.isNotBlank()) {
                batch.response
            } else if (batch.errorDetails != null) {
                "فشل: ${batch.errorDetails}"
            } else {
                "لم يكتمل بعد"
            }
            val responseEscaped = escapeXml(responseText)
            val statusEscaped = escapeXml(batch.status.labelAr)

            sb.append("""        <row r="$rowIdx" ht="85" customHeight="0">
            <c r="A$rowIdx" s="2"><v>${batch.batchNumber}</v></c>
            <c r="B$rowIdx" s="2" t="inlineStr"><is><t xml:space="preserve">$originalEscaped</t></is></c>
            <c r="C$rowIdx" s="2" t="inlineStr"><is><t xml:space="preserve">$responseEscaped</t></is></c>
            <c r="D$rowIdx" s="2" t="inlineStr"><is><t>$statusEscaped</t></is></c>
        </row>
""")
            rowIdx++
        }

        sb.append("""    </sheetData>
</worksheet>""")
        return sb.toString()
    }
}
