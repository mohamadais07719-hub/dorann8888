package com.example

import com.example.data.export.ExcelExporter
import com.example.data.model.BatchItem
import com.example.data.model.BatchStatus
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.util.zip.ZipFile

class ExampleUnitTest {

    @Test
    fun testCommentsChunking() {
        val comments = (1..25).map { "تعليق تجريبي رقم $it" }
        val batches = comments.chunked(10).mapIndexed { idx, list ->
            BatchItem(batchNumber = idx + 1, comments = list)
        }

        assertEquals(3, batches.size)
        assertEquals(10, batches[0].comments.size)
        assertEquals(10, batches[1].comments.size)
        assertEquals(5, batches[2].comments.size)
    }

    @Test
    fun testBatchFormatting() {
        val comments = listOf("الخدمة سريعة", "السعر مناسب")
        val batch = BatchItem(batchNumber = 1, comments = comments)

        val formatted = batch.originalCommentsFormatted
        assertTrue(formatted.contains("1. الخدمة سريعة"))
        assertTrue(formatted.contains("2. السعر مناسب"))
    }

    @Test
    fun testExcelXlsxGeneration() {
        val tempDir = File(System.getProperty("java.io.tmpdir"), "test_export_${System.currentTimeMillis()}").apply { mkdirs() }
        val batches = listOf(
            BatchItem(
                batchNumber = 1,
                comments = listOf("تعليق 1", "تعليق 2"),
                response = "رد تجريبي ممتاز",
                status = BatchStatus.SUCCESS
            )
        )

        // Mock context using file
        val mockContext = object : android.content.ContextWrapper(null) {
            override fun getCacheDir(): File = tempDir
        }

        val file = ExcelExporter.createExcelFile(mockContext, batches, "test_analysis")
        assertTrue(file.exists())
        assertTrue(file.length() > 0)

        // Verify valid zip structure
        ZipFile(file).use { zip ->
            assertNotNull(zip.getEntry("[Content_Types].xml"))
            assertNotNull(zip.getEntry("xl/workbook.xml"))
            assertNotNull(zip.getEntry("xl/worksheets/sheet1.xml"))
            assertNotNull(zip.getEntry("xl/styles.xml"))
        }

        tempDir.deleteRecursively()
    }
}
